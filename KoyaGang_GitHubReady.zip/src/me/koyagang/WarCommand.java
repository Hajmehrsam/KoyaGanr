package me.koyagang;

import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class WarCommand implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) return false;
        Player p = (Player) sender;
        if (args.length == 0) {
            p.sendMessage("/war <setspawn|join|leave>");
            return true;
        }
        String sub = args[0];
        p.sendMessage("Executed war command: " + sub);
        return true;
    }
}