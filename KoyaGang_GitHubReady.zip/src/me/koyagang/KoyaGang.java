package me.koyagang;

import org.bukkit.plugin.java.JavaPlugin;

public class KoyaGang extends JavaPlugin {
    @Override
    public void onEnable() {
        getCommand("gang").setExecutor(new GangCommand());
        getCommand("gangchat").setExecutor(new GangChatCommand());
        getCommand("war").setExecutor(new WarCommand());
    }
}