package me.koyagang;

import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class GangCommand implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) return false;
        Player p = (Player) sender;
        if (args.length < 2) {
            p.sendMessage("/gang <create|freeze|unfreeze|kick|delete> <name>");
            return true;
        }
        String sub = args[0];
        String name = args[1];
        p.sendMessage("Executed: " + sub + " on gang " + name);
        return true;
    }
}