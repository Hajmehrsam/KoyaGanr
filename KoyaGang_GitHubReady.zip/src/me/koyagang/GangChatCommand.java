package me.koyagang;

import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class GangChatCommand implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) return false;
        Player p = (Player) sender;
        String msg = String.join(" ", args);
        p.sendMessage("[GangChat] " + p.getName() + ": " + msg);
        return true;
    }
}